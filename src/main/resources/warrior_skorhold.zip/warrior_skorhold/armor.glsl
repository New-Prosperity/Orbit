#ifdef VSH


if(RVC_0 == <internal-id.r>
&& RVC_1 == <internal-id.g>
&& RVC_2 == <internal-id.b>) {
    if(cube==STASIS_CHESTPLATE) {
        removeAll = 1;
        cems = addCem(cems,WARRIOR_CHESTPLATE);
    }
    if(cube==STASIS_RIGHT_ARM) {
        removeAll = 1;
        cems = addCem(cems,WARRIOR_RIGHT_ARM);
    }
    if(cube==STASIS_LEFT_ARM) {
        removeAll = 1;
        cems = addCem(cems,WARRIOR_LEFT_ARM);
    }
    if(cube==STASIS_RIGHT_BOOT) {
        removeAll = 1;
        cems = addCem(cems,WARRIOR_RIGHT_BOOT);
    }
    if(cube==STASIS_LEFT_BOOT) {
        removeAll = 1;
        cems = addCem(cems,WARRIOR_LEFT_BOOT);
    }
    if(cube==STASIS_INNER_ARMOR) {
        removeAll = 1;
        cems = addCem(cems,WARRIOR_INNER_ARMOR);
    }
    if(cube==STASIS_LEFT_LEG) {
        removeAll = 1;
        cems = addCem(cems,WARRIOR_LEFT_LEG);
    }
    if(cube==STASIS_RIGHT_LEG) {
        removeAll = 1;
        cems = addCem(cems,WARRIOR_RIGHT_LEG);
    }
}

#endif

#ifdef FSH

    case WARRIOR_CHESTPLATE: {
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(0,0,-4.5), vec3(4,6,2)*0.77,   // Pos, Size
       PIX, vec3(0, 0, 0),
       relativeUv(20,20,-8,-4,RelativeCords), relativeUv(36,16,-8,4,RelativeCords), // up down
       relativeUv(20,20,8,12,RelativeCords), relativeUv(28,20,4,12,RelativeCords), // north west
       relativeUv(32,20,8,12,RelativeCords), relativeUv(16,20,4,12,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(0,0,-4.5), vec3(4,6,2)*0.8,   // Pos, Size 
       PIX, vec3(0, 0, 0),
       relativeUv(20,4,8,-4,RelativeCords), relativeUv(28,0,8,4,RelativeCords), // up down
       relativeUv(20,4,8,12,RelativeCords), relativeUv(28,4,4,12,RelativeCords), // north west
       relativeUv(40,4,-8,12,RelativeCords), relativeUv(16,4,4,12,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(-1.388,-1.5,-6.1), vec3(2,2.5,1)*0.83,   // Pos, Size
       PIX*NIZ9*NIZ9*NIZ9, vec3(0, 0, 0),
       relativeUv(46,16,4,-2,RelativeCords), relativeUv(46,14,4,-2,RelativeCords), // up down
       relativeUv(44,11,-4,5,RelativeCords), relativeUv(63,0,1,1,RelativeCords), // north west
       relativeUv(64,0,-1,1,RelativeCords), relativeUv(44,6,2,5,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(1.388,-1.5,-6.1), vec3(2,2.5,1)*0.83,   // Pos, Size
       PIX*PIZ9*PIZ9*PIZ9, vec3(0, 0, 0),
       relativeUv(50,8,-4,-2,RelativeCords), relativeUv(50,10,-4,-2,RelativeCords), // up down
       relativeUv(40,6,4,5,RelativeCords), relativeUv(44,11,2,5,RelativeCords), // north west
       relativeUv(63,0,1,1,RelativeCords), relativeUv(64,0,-1,1,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(-3.2,0,-1.7), vec3(0.5,1.5,2.5)*0.785,   // Pos, Size
       PIX*Rotate3(PI*0.0278, Y), vec3(0, 0, 0),
       relativeUv(15,21,1,-5,RelativeCords), relativeUv(14,16,1,5,RelativeCords), // up down
       relativeUv(16,17,1,3,RelativeCords), relativeUv(10,4,-5,3,RelativeCords), // north west
       relativeUv(18,17,-1,3,RelativeCords), relativeUv(5,1,5,3,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(3.32,0,0.5), vec3(0.5,1.5,2.5)*0.78,   // Pos, Size
       PIX*PIY62, vec3(0, 0, 0),
       relativeUv(14,16,-1,5,RelativeCords), relativeUv(13,16,-1,5,RelativeCords), // up down
       relativeUv(11,15,-1,3,RelativeCords), relativeUv(10,5,5,3,RelativeCords), // north west
       relativeUv(11,15,1,3,RelativeCords), relativeUv(15,8,-5,3,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(3.2,0,-1.7), vec3(0.5,1.5,2.5)*0.785,   // Pos, Size
       PIX*Rotate3(PI*-0.0278, Y), vec3(0, 0, 0),
       relativeUv(16,21,-1,-5,RelativeCords), relativeUv(15,16,-1,5,RelativeCords), // up down
       relativeUv(17,17,-1,3,RelativeCords), relativeUv(5,1,5,3,RelativeCords), // north west
       relativeUv(17,17,1,3,RelativeCords), relativeUv(5,1,5,3,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(-3.32,0,0.5), vec3(0.5,1.5,2.5)*0.78,   // Pos, Size
       PIX*NIY62, vec3(0, 0, 0),
       relativeUv(13,16,1,5,RelativeCords), relativeUv(12,16,1,5,RelativeCords), // up down
       relativeUv(10,15,1,3,RelativeCords), relativeUv(15,8,-5,3,RelativeCords), // north west
       relativeUv(12,15,-1,3,RelativeCords), relativeUv(10,5,5,3,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
        break;
    }

    case WARRIOR_RIGHT_ARM: {
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(0,0,-4.2), vec3(2,6,2)*0.92,   // Pos, Size // 
       PIX, vec3(0, 0, 0),
       relativeUv(40,16,4,4,RelativeCords), relativeUv(40,20,-4,-4,RelativeCords), // up down
       relativeUv(60,8,4,12,RelativeCords), relativeUv(60,20,-4,12,RelativeCords), // north west
       relativeUv(56,8,-4,12,RelativeCords), relativeUv(56,8,4,12,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(0.25,0,-10.6), vec3(0.5,1,2.5)*0.83,   // Pos, Size // 
       PIX, vec3(0, 0, 0),
       relativeUv(12,23,-1,-5,RelativeCords), relativeUv(11,18,-1,5,RelativeCords), // up down
       relativeUv(13,21,-1,2,RelativeCords), relativeUv(15,13,-5,2,RelativeCords), // north west
       relativeUv(13,21,1,2,RelativeCords), relativeUv(10,11,5,2,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(0.5,0,-8.6), vec3(1,2,2.5)*0.836,   // Pos, Size //
       PIX*PIY12, vec3(0, 0, 0),
       relativeUv(2,0,-2,5,RelativeCords), relativeUv(4,0,-2,5,RelativeCords), // up down
       relativeUv(7,7,2,4,RelativeCords), relativeUv(10,19,-5,4,RelativeCords), // north west
       relativeUv(7,7,-2,4,RelativeCords), relativeUv(10,15,-5,4,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(-0.64,0,-7.88), vec3(2.5,1.5,2.5)*0.8,   // Pos, Size
       PIX*Rotate3(PI*0.0833, Y), vec3(0, 0, 0),
       relativeUv(5,22,-5,5,RelativeCords), relativeUv(5,17,-5,5,RelativeCords), // up down
       relativeUv(0,11,5,3,RelativeCords), relativeUv(5,14,-5,3,RelativeCords), // north west
       relativeUv(5,5,-5,3,RelativeCords), relativeUv(5,8,-5,3,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(0,0,-4), vec3(2,6,2)*0.85,   // Pos, Size //
       PIX, vec3(0, 0, 0),
       relativeUv(48,16,-4,4,RelativeCords), relativeUv(52,16,-4,4,RelativeCords), // up down
       relativeUv(44,20,4,12,RelativeCords), relativeUv(48,20,4,12,RelativeCords), // north west
       relativeUv(56,20,-4,12,RelativeCords), relativeUv(44,20,-4,12,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
        break;
    }
    case WARRIOR_LEFT_ARM: {
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(0,0,-4.2), vec3(2,6,2)*0.92,   // Pos, Size // 
       PIX, vec3(0, 0, 0),
       relativeUv(40,16,4,4,RelativeCords), relativeUv(40,16,-4,4,RelativeCords), // up down
       relativeUv(56,8,-4,12,RelativeCords), relativeUv(56,20,4,12,RelativeCords), // north west
       relativeUv(60,8,4,12,RelativeCords), relativeUv(60,8,-4,12,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(0.25,0,-10.6), vec3(0.5,1,2.5)*0.83,   // Pos, Size // 
       PIX, vec3(0, 0, 0),
       relativeUv(12,18,-1,5,RelativeCords), relativeUv(11,18,-1,5,RelativeCords), // up down
       relativeUv(13,21,-1,2,RelativeCords), relativeUv(10,13,5,2,RelativeCords), // north west
       relativeUv(13,21,1,2,RelativeCords), relativeUv(15,11,-5,2,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(0.5,0,-8.6), vec3(1,2,2.5)*0.836,   // Pos, Size //
       PIX*PIY12, vec3(0, 0, 0),
       relativeUv(2,0,-2,5,RelativeCords), relativeUv(4,0,-2,5,RelativeCords), // up down
       relativeUv(7,7,2,4,RelativeCords), relativeUv(10,19,-5,4,RelativeCords), // north west
       relativeUv(7,7,-2,4,RelativeCords), relativeUv(10,15,-5,4,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(-0.64,0,-7.88), vec3(2.5,1.5,2.5)*0.8,   // Pos, Size
       PIX*Rotate3(PI*0.0833, Y), vec3(0, 0, 0),
       relativeUv(5,22,-5,5,RelativeCords), relativeUv(5,17,-5,5,RelativeCords), // up down
       relativeUv(0,11,5,3,RelativeCords), relativeUv(5,14,-5,3,RelativeCords), // north west
       relativeUv(5,5,-5,3,RelativeCords), relativeUv(5,8,-5,3,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(0,0,-4), vec3(2,6,2)*0.85,   // Pos, Size //
       PIX, vec3(0, 0, 0),
       relativeUv(48,16,-4,4,RelativeCords), relativeUv(52,16,-4,4,RelativeCords), // up down
       relativeUv(56,20,-4,12,RelativeCords), relativeUv(48,20,4,12,RelativeCords), // north west
       relativeUv(44,20,4,12,RelativeCords), relativeUv(44,20,-4,12,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
        break;
    }

    case WARRIOR_RIGHT_BOOT: {
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(0,0,-1.5), vec3(2,2.5,2)*0.82,   // Pos, Size
       PIX, vec3(0, 0, 0),
       relativeUv(64,0,-1,1,RelativeCords), relativeUv(12,23,-4,4,RelativeCords), // up down
       relativeUv(16,27,-4,5,RelativeCords), relativeUv(8,27,4,5,RelativeCords), // north west
       relativeUv(4,27,4,5,RelativeCords), relativeUv(4,27,-4,5,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(0,0,-1.5), vec3(2,2.5,2)*0.9,   // Pos, Size
       PIX, vec3(0, 0, 0),
       relativeUv(63,0,1,1,RelativeCords), relativeUv(18,0,-4,4,RelativeCords), // up down
       relativeUv(60,3,4,5,RelativeCords), relativeUv(56,3,4,5,RelativeCords), // north west
       relativeUv(60,20,4,5,RelativeCords), relativeUv(44,1,-4,5,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
        break;
    }

    case WARRIOR_LEFT_BOOT: {
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(0,0,-1.5), vec3(2,2.5,2)*0.82,   // Pos, Size
       PIX, vec3(0, 0, 0),
       relativeUv(64,0,-1,1,RelativeCords), relativeUv(12,27,-4,-4,RelativeCords), // up down
       relativeUv(4,27,4,5,RelativeCords), relativeUv(12,27,-4,5,RelativeCords), // north west
       relativeUv(16,27,-4,5,RelativeCords), relativeUv(0,27,4,5,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(0,0,-1.5), vec3(2,2.5,2)*0.9,   // Pos, Size
       PIX, vec3(0, 0, 0),
       relativeUv(63,0,1,1,RelativeCords), relativeUv(18,4,-4,-4,RelativeCords), // up down
       relativeUv(60,20,4,5,RelativeCords), relativeUv(60,3,-4,5,RelativeCords), // north west
       relativeUv(60,3,4,5,RelativeCords), relativeUv(40,1,4,5,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
        break;
    }


    case WARRIOR_RIGHT_LEG: {
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(0,0,-7.5), vec3(2,4,2)*0.92,   // Pos, Size
       PIX, vec3(0, 0, 0),
       relativeUv(8,20,-4,4,RelativeCords), relativeUv(12,20,-4,4,RelativeCords), // up down
       relativeUv(4,24,4,8,RelativeCords), relativeUv(12,24,-4,8,RelativeCords), // north west
       relativeUv(12,24,4,8,RelativeCords), relativeUv(0,24,4,8,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(0,-1.4,-8.1), vec3(2,1.5,1)*0.93,   // Pos, Size ///
       PIX*PIX9*PIX9*PIX9, vec3(0, 0, 0),
       relativeUv(2,0,4,2,RelativeCords), relativeUv(6,0,4,2,RelativeCords), // up down
       relativeUv(6,2,-4,3,RelativeCords), relativeUv(6,2,2,3,RelativeCords), // north west
       relativeUv(8,2,4,3,RelativeCords), relativeUv(0,2,2,3,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(-2.2,0,-8), vec3(0.5,1.5,2)*0.93,   // Pos, Size ///
       PIX*NIY12, vec3(0, 0, 0),
       relativeUv(5,5,1,4,RelativeCords), relativeUv(4,5,1,4,RelativeCords), // up down
       relativeUv(6,5,1,3,RelativeCords), relativeUv(4,5,-4,3,RelativeCords), // north west
       relativeUv(8,5,-1,3,RelativeCords), relativeUv(4,8,-4,3,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(-2,0,-6.3), vec3(0.5,1.5,1.5)*0.9,   // Pos, Size
       PIX*Rotate3(PI*-0.0833, Y), vec3(0, 0, 0),
       relativeUv(6,11,1,3,RelativeCords), relativeUv(5,11,1,3,RelativeCords), // up down
       relativeUv(8,8,-1,3,RelativeCords), relativeUv(0,11,3,3,RelativeCords), // north west
       relativeUv(8,8,-1,3,RelativeCords), relativeUv(3,14,-3,3,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(0,0,-5.5), vec3(2,6,2)*0.85,   // Pos, Size
       PIX, vec3(0, 0, 0),
       relativeUv(36,0,-4,4,RelativeCords), relativeUv(40,0,-4,4,RelativeCords), // up down
       relativeUv(32,4,4,12,RelativeCords), relativeUv(40,4,-4,12,RelativeCords), // north west
       relativeUv(44,4,-4,12,RelativeCords), relativeUv(28,4,4,12,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
        break;
    }
    case WARRIOR_LEFT_LEG: {
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(0,0,-7.5), vec3(2,4,2)*0.92,   // Pos, Size
       PIX, vec3(0, 0, 0),
       relativeUv(8,20,-4,4,RelativeCords), relativeUv(12,20,-4,4,RelativeCords), // up down
       relativeUv(12,24,4,8,RelativeCords), relativeUv(4,24,-4,8,RelativeCords), // north west
       relativeUv(4,24,4,8,RelativeCords), relativeUv(8,24,4,8,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(0,1.4,-8.1), vec3(2,1.5,1)*0.93,   // Pos, Size ///
       PIX*NIX9*NIX9*NIX9, vec3(0, 0, 0),
       relativeUv(2,0,4,2,RelativeCords), relativeUv(6,0,4,2,RelativeCords), // up down
       relativeUv(8,2,4,3,RelativeCords), relativeUv(0,2,2,3,RelativeCords), // north west
       relativeUv(6,2,-4,3,RelativeCords), relativeUv(6,2,2,3,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(-2.2,0,-8), vec3(0.5,1.5,2)*0.93,   // Pos, Size ///
       PIX*NIY12, vec3(0, 0, 0),
       relativeUv(5,5,1,4,RelativeCords), relativeUv(4,5,1,4,RelativeCords), // up down
       relativeUv(8,5,-1,3,RelativeCords), relativeUv(0,5,4,3,RelativeCords), // north west
       relativeUv(6,5,1,3,RelativeCords), relativeUv(0,8,4,3,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(-2,0,-6.3), vec3(0.5,1.5,1.5)*0.9,   // Pos, Size
       PIX*Rotate3(PI*-0.0833, Y), vec3(0, 0, 0),
       relativeUv(6,11,1,3,RelativeCords), relativeUv(5,11,1,3,RelativeCords), // up down
       relativeUv(8,8,-1,3,RelativeCords), relativeUv(0,14,3,3,RelativeCords), // north west
       relativeUv(8,8,-1,3,RelativeCords), relativeUv(3,11,-3,3,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
       ADD_BOX_WITH_ROTATION_ROTATE(vec3(0,0,-5.5), vec3(2,6,2)*0.85,   // Pos, Size
       PIX, vec3(0, 0, 0),
       relativeUv(36,0,-4,4,RelativeCords), relativeUv(40,0,-4,4,RelativeCords), // up down
       relativeUv(44,4,-4,12,RelativeCords), relativeUv(36,4,4,12,RelativeCords), // north west
       relativeUv(32,4,4,12,RelativeCords), relativeUv(32,4,-4,12,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
        break;
    }
    case WARRIOR_INNER_ARMOR: {
       ADD_BOX_EXT_WITH_ROTATION_ROTATE(vec3(0,0,-5), vec3(3.86,6,2)*0.83,   // Pos, Size
       PIX, vec3(0, 0, 0),
       relativeUv(20,16,8,4,RelativeCords), relativeUv(28,16,8,4,RelativeCords), // up down
       relativeUv(20,20,8,12,RelativeCords), relativeUv(28,20,4,12,RelativeCords), // north west
       relativeUv(40,20,-8,12,RelativeCords), relativeUv(16,20,4,12,RelativeCords), // south east
       2, 2,
       2, 2,
       2, 2);
        break;
    }



#endif